# CS 4050 Group Algorithm Engineering Assignment 2

Divide and conquer (inversion counting) and dynamic programming (coin change).

**Group:** Isaac Dierker, Noah Pipes, Andrew W. Smith

## Language and version

- Python 3.11.9 (also tested with Python 3.13)
- `CS_4050_GAE2.py` uses the standard library only (`random`, `time`, `csv`, `os`, `statistics`); nothing to instal.
- `plot_results.py` (optional, only for the report figures) needs matplotlib: `pip install matplotlib`.

## How to run

From the folder containing `CS_4050_GAE2.py`:

```
python .\CS_4050_GAE2.py        # Windows
python3 CS_4050_GAE2.py         # macOS / Linux
```

A full run takes roughly 1 minute depending on the machiene. Most of that time is the repeated brute-force timings at n = 10,000 and 20,000 and the last naive-recursion runs in Experiment 1.

To redraw the report figures from the CSV files afterwards:

```
python plot_results.py
```

This reads `results/*.csv` and writes PNG files to `report_figures/`. Plotting is kept in this seperate script so it never affects the timings.

The program prints its results to the terminal and writes CSV files to a `results/` folder, which is created next to the script if it doesn't exist.

## Reproducibility

- The run starts with `random.seed(1)`, and the coin-change validation, Experiment 1 and Experiment 2 each re-seed (`random.seed(2)`, `3`, `4`) at their start.
- The inversion crossover search draws a timing-dependent number of random arrays, which is why the later experiments reseed: their coin systems, solutions and recursion counts are the same on every run.
- Every timing is repeated and the **median** is reported (`TIMING_REPS = 5`; brute force at n = 10,000 and 20,000 and bottom-up DP use the same helper, `median_time`). Inputs are generated before the timer starts and CSV files are written only after all timing is done.
- Runtimes still depend on the hardware and on what else the machine is doing, so they will vary betwen machines and between runs. The CSV files in `results/` and the numbers in the report come from one full run with Python 3.13 on a 4-core Intel Xeon 2.1 GHz Linux machine.

## What the program runs, in order

| Step | Function | Assignment part |
|---|---|---|
| 1 | `validation()` | **Part 1B.** Checks 11 hand-built arrays (already sorted, reverse sorted, nearly sorted and randomly ordered, all with distinct values) against expected counts, and checks that merge-and-count also returns the sorted array. Cross-checks merge-and-count against brute force on 200 random arrays of distinct values (lengths 1 to 100). Finds the crossover size and times both methods (median of repeated runs) for n = 1 to 20,000. |
| 2 | `coin_algorithm_validation()` | **Part 2B.** Runs all four solvers through the common interface on 12 hand-built cases (including target 0, two impossible cases and a case with more than one optimal answer). Then runs 100 random small instances and requires naive, top-down and bottom-up to agree on the optimal coin count. Every returned result is checked by `validate_solution`. |
| 3 | `part_2c1()` | **Part 2C, Experiment 1.** Counts recursive calls, distinct target states and cache hits for naive recursion and top-down memoization for A = 1, 2, 3, ... untill naive recursion becomes impractical. Safety cutoff: the experiment stops after the first A where naive recursion needs more than `NAIVE_CALL_CUTOFF = 20,000,000` recursive calls (A = 42 on our run). |
| 4 | `part_2c2()` | **Part 2C, Experiment 2.** Runs bottom-up DP with a fixed set of k = 7 coins for A = 2^8 to 2^19 and records A, bit length, DP states processed and median runtime. |
| 5 | `greedy_counterexample_search()` | **Part 2B.** Searches every coin system {1, a, b} with b <= 10 and targets 1 to 30 for cases where greedy uses more coins than the bottom-up optimum. Keeps the smallest failing target for each system. |

### Common interface and validator

All four coin-change solvers are called through wrappers (`solve_greedy`, `solve_naive`, `solve_top_down`, `solve_bottom_up`) that return either `(coin_count, chosen_coins)` or the string `IMPOSSIBLE`. `validate_solution(D, A, result)` checks every returned result independently of the solver: the coins must sum to A, every coin must be one of the denominations, and the reported count must equal the number of coins.

### Validation

Every correctness check uses `assert`. If the program finishs without an `AssertionError`, all of these passed:

- The hand-built inversion tests (counts and sorted output) and the 200 random inversion cross-checks against brute force.
- The hand-built coin-change tests for naive, top-down and bottom-up (optimal coin count).
- `validate_solution` on every result from all four solvers, in both the hand-built and the random coin-change tests.
- The random coin-change agreement checks (naive, top-down and bottom-up give the same optimal count).
- The counterexample search found the required case D = {1, 3, 4}, A = 6, and at least 3 distinct counterexamples.

Greedy's coin count is not asserted, because greedy is not expeted to always be optimal. Its result for each hand-built case is printed as `Greedy correct: True/False` (its coin list is still validated).

## Output files (`results/`)

| File | Columns | Produced by |
|---|---|---|
| `inversion_crossover.csv` | `n, median_merge_seconds, median_brute_seconds` | First array size at which the median merge-and-count time beat the median brute-force time |
| `inversion_runtime.csv` | `n, median_merge_seconds, median_brute_seconds, brute_over_merge` | Median runtime of both inversion counters for n = 1, 10, 50, 100, 200, 500, 1,000, 2,000, 5,000, 10,000, 20,000 |
| `experiment1_repeated_subproblems.csv` | `denominations, A, naive_recursive_calls, naive_distinct_states, topdown_recursive_calls, topdown_distinct_states, topdown_cache_hits, optimal_coin_count, solution` | Experiment 1 |
| `experiment2_pseudo_polynomial.csv` | `denominations, A, bit_length_A, dp_states_processed, median_runtime_seconds` | Experiment 2 |
| `greedy_counterexamples.csv` | `denominations, A, greedy_coins, greedy_count, optimal_coins, optimal_count` | Greedy counterexample search |

Coin lists are stored in one cell separated by spaces, for example `4 1 1` means the coins [4, 1, 1].

## Files in this submission

- `CS_4050_GAE2.py`: all algorithms, validators, generators, the counterexample search and the experiments
- `plot_results.py`: draws the report figures from the CSV files (optional; needs matplotlib)
- `results/*.csv`: the data behind the tables and figures in the report
- `report_figures/*.png`: the figures used in the report
- `Engineering Report.docx`: methods, correctness and complexity, validation, results and interpretation
- `Engineering Reflection.docx`: Part III cross-paradigm reflection
- `Group Contribution Statement.docx`: each member's contributions
- `AI Contribution Statement.docx`: AI tools used and how their output was checked
