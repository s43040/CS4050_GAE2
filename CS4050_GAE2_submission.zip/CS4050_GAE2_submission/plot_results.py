# Draws the report figures from the CSV files that CS_4050_GAE2.py writes to results/.
# Plotting is kept in this separate script so that file I/O and plotting never affect the timings.
# Requires matplotlib (pip install matplotlib). Run after CS_4050_GAE2.py:  python plot_results.py
import csv
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RESULTS_DIR = "results"
FIGURES_DIR = "report_figures"
BLUE, ORANGE, GRAY = "#2563eb", "#ea580c", "gray"

def read_csv(filename):
    with open(os.path.join(RESULTS_DIR, filename), newline="") as f:
        return list(csv.DictReader(f))

def save(fig, filename):
    os.makedirs(FIGURES_DIR, exist_ok=True)
    path = os.path.join(FIGURES_DIR, filename)
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)
    print(f"Wrote {path}")

plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})

# Figure: inversion counting runtime (Part 1B)
rows = read_csv("inversion_runtime.csv")
crossover = int(read_csv("inversion_crossover.csv")[0]["n"])
n = [int(r["n"]) for r in rows]
fig, ax = plt.subplots(figsize=(6.5, 3.6))
ax.loglog(n, [float(r["median_brute_seconds"]) for r in rows], "o-", color=ORANGE, label="Brute force (all pairs)")
ax.loglog(n, [float(r["median_merge_seconds"]) for r in rows], "s-", color=BLUE, label="Divide and conquer (merge-and-count)")
ax.axvline(crossover, color=GRAY, ls=":", lw=1)
ax.text(crossover * 1.1, 1e-2, f"first crossover\nn = {crossover}", color=GRAY, fontsize=8)
ax.set_xlabel("Array size n (log scale)")
ax.set_ylabel("Median runtime, seconds (log scale)")
ax.set_title("Inversion counting: median of repeated timings")
ax.legend(frameon=False)
ax.grid(alpha=0.25, which="both")
save(fig, "inversion_runtime.png")

# Figure: Experiment 1, recursive calls (Part 2C)
rows = read_csv("experiment1_repeated_subproblems.csv")
A = [int(r["A"]) for r in rows]
fig, ax = plt.subplots(figsize=(6.5, 3.4))
ax.semilogy(A, [int(r["naive_recursive_calls"]) for r in rows], "o-", color=ORANGE, ms=4, label="Naive recursion")
ax.semilogy(A, [int(r["topdown_recursive_calls"]) for r in rows], "s-", color=BLUE, ms=4, label="Top-down memoized")
ax.axhline(20_000_000, color=GRAY, ls=":", lw=1)
ax.text(1, 2.6e7, "safety cutoff (20,000,000 calls)", color=GRAY, fontsize=8)
ax.set_xlabel(f"Target amount A   (D = {{{rows[0]['denominations'].replace(' ', ', ')}}})")
ax.set_ylabel("Recursive calls (log scale)")
ax.set_title("Experiment 1: recursive calls, naive vs. memoized")
ax.legend(frameon=False, loc="center right")
ax.grid(alpha=0.25)
save(fig, "experiment1_calls.png")

# Figure: Experiment 2, pseudo-polynomial scaling (Part 2C)
rows = read_csv("experiment2_pseudo_polynomial.csv")
A = [int(r["A"]) for r in rows]
bits = [int(r["bit_length_A"]) for r in rows]
runtime = [float(r["median_runtime_seconds"]) for r in rows]
fig, (left, right) = plt.subplots(1, 2, figsize=(6.5, 3.0))
left.plot([a / 1e3 for a in A], runtime, "o-", color=BLUE, ms=4)
left.set_xlabel("Target amount A (thousands)")
left.set_ylabel("Median runtime (s)")
left.set_title("Runtime vs. A (linear)", fontsize=10)
right.semilogy(bits, runtime, "o-", color=ORANGE, ms=4)
right.set_xlabel("Bit length of A")
right.set_ylabel("Median runtime, s (log)")
right.set_title("Runtime vs. bits (exponential)", fontsize=10)
for ax in (left, right):
    ax.grid(alpha=0.25)
fig.suptitle(f"Experiment 2: bottom-up DP, D = {{{rows[0]['denominations'].replace(' ', ', ')}}}", fontsize=10)
save(fig, "experiment2_scaling.png")
